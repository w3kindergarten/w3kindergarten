package w3kindergarten.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import w3kindergarten.model.W3KindergatenService;
import w3kindergarten.model.dto.NoticeBoardDTO;
import w3kindergarten.model.dto.UsersDTO;

@WebServlet("/control")
public class W3kindergartenFrontController extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		System.out.println("control process()");
	
		// Commnad Pattern
		String command = request.getParameter("command");
		try {
			if(command.equals("signup")) {
				signUp(request, response);
			}else if(command.equals("signin")) {
				signIn(request, response);
			}else if(command.equals("userUpdate")) {
				userUpdate(request, response);
			}else if(command.equals("userUpdateReq")) {
				userUpdateReq(request, response);
			}else if(command.equals("userDelete")) {
				userDelete(request, response);
			}else if(command.equals("board")) {
				
			}
			
			
			
		}catch(Exception e) {
			request.setAttribute("errorMsg", e.getMessage());
			request.getRequestDispatcher("showError.jsp").forward(request, response);
			e.printStackTrace();
		}
	}
	
	// username, password 필수 입력 (password 5자 이상의 값 입력 필요)
	// 중복처리 작업 추가 필요
	protected void signUp(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "showError.jsp";
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String nickname = request.getParameter("nickname");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");

		UsersDTO userdto = null;
		try {
			if(username != null && username.length() != 0 && password != null && nickname.length() != 0 && nickname != null) {	//&& password.length()>=5 : 비밀번호 5자리 이상
				userdto = new UsersDTO(username,password,nickname,email,phone);

				boolean result = W3KindergatenService.userAdd(userdto);
				if(result) {
					request.setAttribute("user", userdto);
					request.setAttribute("successMsg", "가입 완료");
					url="successMessage.html";
					//url = "main.jsp";
				}else {
					request.setAttribute("errorMsg", "다시 시도해주세요.");
				}
			}else {
				request.setAttribute("errorMsg", "다시 시도해주세요.");
			}
		}catch(Exception e) {
			request.setAttribute("errorMsg", e.getMessage());
			e.printStackTrace();
		}
		request.getRequestDispatcher(url).forward(request, response);
	}
	
	
	// 로그인, 세션 생성
	protected void signIn(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
		String url = "showError.jsp";
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		
		try {
			if(W3KindergatenService.userNameGet(userName).equals(userName) && W3KindergatenService.userPasswordGet(userName).equals(password)) {
				HttpSession session = request.getSession();
				session.setAttribute("user", W3KindergatenService.userGet(userName));//W3KindergatenService.userGet(userName)
				url = "main.jsp";

				if(W3KindergatenService.userPermission(userName) == 1) {
					request.setAttribute("successMsg", "관리자 로그인 성공");
					response.sendRedirect(url);
				}else {
					request.setAttribute("successMsg", "사용자 로그인 성공");
					response.sendRedirect(url);
				}
			}
		}catch(Exception e) {
			request.setAttribute("errorMsg", e.getMessage());
			e.printStackTrace();
			response.sendRedirect(url);
			System.out.println("없는 아이디 2");
		}
//		request.getRequestDispatcher(url).forward(request, response);
	}

	
	protected void userUpdateReq(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "showError.jsp";
		try {
			String username = request.getParameter("username");
			System.out.println("username: "+username);
			request.setAttribute("user", W3KindergatenService.userGet(request.getParameter("username")));
			
			url = "userUpdate.jsp";
			
//			System.out.println(request.getAttribute("user") + " " + url);
		}catch(Exception e) {
//			request.setAttribute("errorMsg", e.getMessage());
			request.setAttribute("errorMsg", 111);
			e.printStackTrace();
		}
		request.getRequestDispatcher(url).forward(request, response);
	}
	
	
	protected void userUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		String nickname = request.getParameter("nickname");
		String phone = request.getParameter("phone");

		String url = "showError.jsp";

		UsersDTO user = new UsersDTO(username, password, email, nickname, phone);
		try {
			if(W3KindergatenService.userUpdate(user) == true) {
				W3KindergatenService.userUpdate(user);
				url = "successView.jsp";
				request.setAttribute("username", username);
				request.setAttribute("password", password);
				request.setAttribute("email", email);
				request.setAttribute("nickname", nickname);
				request.setAttribute("phone", phone);
			}
		}catch(Exception e) {
			System.out.println("userUpdate() catch");
			request.setAttribute("errorMsg", e.getMessage());
			e.printStackTrace();
		}
		System.out.println("userUpdate() request 이전");
		request.getRequestDispatcher(url).forward(request, response);
	}
	
	
	protected void userDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("userDelete()");
		String url = "showError.jsp";
		try {
			W3KindergatenService.userDelete(request.getParameter("username"));
			url = "main.jsp";
			// 세션종료 코드
			
		}catch(SQLIntegrityConstraintViolationException e) {
			request.setAttribute("errorMsg", "사용자가 존재하지 않습니다.");
		}catch(Exception e) {
			request.setAttribute("errorMsg", e.getMessage());
		}
		request.getRequestDispatcher(url).forward(request, response);
		
		
	}
	
	
	
	
	
	
	
	
	protected void userList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "showError.jsp";
		try {
			request.setAttribute("userList", W3KindergatenService.userAllGet());
			url = "userList.jsp";
		}catch(Exception e) {
			request.setAttribute("errorMsg", e.getMessage());
			e.printStackTrace();
		}
		request.getRequestDispatcher(url).forward(request, response);
	}
	
	
	
	
	
	// Board
	protected void boardWrite(HttpServletRequest request, HttpServletResponse response) throws IOException {
		System.out.println("boardWrite()");
		
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		
		// 데이터 유효성 검사
		if(title == null || title.length() == 0 || content == null ||content.length() == 0) {
			response.sendRedirect("write.html");
			return;
		}else {
			NoticeBoardDTO board = new NoticeBoardDTO(title,content);
//			boolean result = W3KindergatenService.contentWrite(board);
			
		}
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	public static void main(String[] args) {
//		String username = "23d3";
//		String password = "2d44";
//		String nickname = "25d5";
//		String email = "2d66";
//		String phone = "2d77";
//		UsersDTO userdto = new UsersDTO(username,password,nickname,email,phone);
//		W3KindergatenService.userAdd(userdto);
//	}

}
