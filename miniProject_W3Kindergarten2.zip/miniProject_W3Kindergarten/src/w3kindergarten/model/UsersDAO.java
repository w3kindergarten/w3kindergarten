package w3kindergarten.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;

import w3kindergarten.model.dto.UsersDTO;
import w3kindergarten.model.util.DBUtil;

public class UsersDAO {
	
	public static boolean addUser(UsersDTO user) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("insert into users values(seq_w3kindergarten_users.nextval,?,?,?,?,?,sysdate,sysdate,2)");
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getEmail());
			pstmt.setString(4, user.getNickName());
			pstmt.setString(5, user.getPhone());
			System.out.println("addUser 1");
			int result = pstmt.executeUpdate();
			if(result == 1) {
				System.out.println("addUser 2");
				return true;
			}
		}finally {
			DBUtil.close(con, pstmt);
		}
		System.out.println("add3");
		return false;
	}
	
	
	public static UsersDTO getUser(String userName) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt= null;
		ResultSet rset = null;
		UsersDTO user = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from users where username = ?");
			pstmt.setString(1, userName);
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				user = new UsersDTO(rset.getInt(1), rset.getString(2), rset.getString(3), rset.getString(4), rset.getString(5), rset.getString(6), rset.getString(7), rset.getString(8), rset.getInt(9));
			}
		}finally {
			DBUtil.close(con, pstmt, rset);
		}
		return user;
	}
	

	public static ArrayList<UsersDTO> getAllUsers() throws SQLException{
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		ArrayList<UsersDTO> users = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("select * from users");
			rset = pstmt.executeQuery();
			
			while(rset.next()) {
				users.add(new UsersDTO(rset.getInt(1),rset.getString(2),rset.getString(3),rset.getString(4),rset.getString(5),rset.getString(6),rset.getString(7), rset.getString(8), rset.getInt(9)));
			}
		}finally {
			DBUtil.close(con, pstmt, rset);
		}
		
		return users;
	}
	
	
	
	
	// password, email, nickname, phone 변경 가능
	public static boolean updateUser(UsersDTO user) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("update users set password=?, email=?, nickname=?, phone=?, modify_date=sysdate where username=?");
			pstmt.setString(1, user.getPassword());
			pstmt.setString(2, user.getEmail());
			pstmt.setString(3, user.getNickName());
			pstmt.setString(4, user.getPhone());
			pstmt.setString(5, user.getUserName());
			
			int result = pstmt.executeUpdate();
			if(result == 1) {
				System.out.println(1);
				return true;
			}
		}finally {
			DBUtil.close(con, pstmt);
		}
		System.out.println(2);
		return false;
	}
	
	
	
	public static boolean deleteUser(String username) throws SQLException {
		System.out.println("dao deleteuser()");
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement("DELETE FROM users WHERE username = ?");
			pstmt.setString(1, username);
			
			int result = pstmt.executeUpdate();
			if(result == 1) {
				return true;
			}
		}finally {
			DBUtil.close(con, pstmt);
		}
		return false;
	}
	
	
	
	
//	public static void main(String[] args) {
////		try {
//////			UsersDTO user2 = new UsersDTO(3,"userna","pass", "email2", "nick","phone1");
//////			boolean r = addUser(user2);
//////			System.out.println(r);
////			
//////			System.out.println(getUser(8).getNickname());
////			System.out.println(deleteUser(1));
////		} catch (SQLException e) {
////			e.printStackTrace();
////		}
////		
//		String username = "23d3";
//		String password = "2d44";
//		String nickname = "25d5";
//		String email = "2d66";
//		String phone = "2d77";
//		UsersDTO userdto = new UsersDTO(username,password,nickname,email,phone);
//		try {
//			addUser(userdto);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		
//	}
	

}
