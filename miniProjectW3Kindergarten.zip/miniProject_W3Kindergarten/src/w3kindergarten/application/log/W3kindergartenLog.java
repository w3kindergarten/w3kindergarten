package w3kindergarten.application.log;

public class W3kindergartenLog {

}
